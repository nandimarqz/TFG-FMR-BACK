<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\API\BaseController;
use App\Models\Student;


class StudentController extends BaseController{

    public function getStudentName(Student $student){
        return $this->sendResponse($student->name.", ".$student->surnames,'Reviews retrieved successfully');
    }
    
}